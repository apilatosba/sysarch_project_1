# Contributions

Briefly describe how each team member has contributed to the project. It goes without saying that every team members should have a good grasp of all parts of the submission.

# Use of AI tools

Did you use any AI tools for the project? If so, which tools did you use?

## Problem 2.6: Bonus

Please specify here how you approached this task, i.e. how do you ensure correctness and how did you optimize the generated code?
